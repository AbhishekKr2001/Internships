<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$db="banking";
	$conn = mysqli_connect($servername, $username, $password,$db);
	
?>